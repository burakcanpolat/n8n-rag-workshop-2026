# Claude Code Kurulumu (Ünite 1.7, B ve C kapıları)

Bu dosyada aynı altı belgeye Claude Code'dan iki yolla bakarsın:

- **B. Grep yolu (P15):** Claude Code kitin `belgeler/` klasöründe dosyaları kelimeyle arar ve okur. Embedding yok, n8n gerekmez.
- **C. MCP köprüsü (P16, P17):** Claude Code, n8n'deki `05-kb-mcp` workflow'unu MCP ile araç olarak çağırır. Anlam araması (embedding) n8n'de çalışır.

Not: bu köprü, n8n instance'ını yöneten MCP sunucusundan farklıdır. Burada yalnız tek bir workflow'un açtığı tek bir araç (`imbat_bilgi_bankasi`) dışarı açılır.

## Hazırlık

- Claude Code kurulu ve oturum açılmış olmalı.
- Terminalde kit klasörüne geç (Mac ve Linux örneği; klasör yolunu kendi yolunla değiştir):

```
cd ~/Downloads/ImbatPedal-Workshop
claude
```

## B. Grep yolu (P15)

Claude Code oturumu kit klasöründe açıkken şunu yaz (P15):

```
belgeler klasöründeki dosyalara bakarak cevap ver ve hangi dosyadan bulduğunu yaz: Rezervasyonumu başlangıçtan 12 saat önce iptal edersem ne kadar iade alırım?
```

**Ne görmelisin:**

- Transcript'te Grep çağrıları (örneğin "iptal" ya da "iade" araması) ve ardından bulunan dosya için Read çağrısı.
- Cevap: yüzde 50 iade; kaynak `03-iptal-ve-iade.md`.
- Bu, n8n Agents Knowledge ile aynı fikir: önce dosya adlarına ve kelimelere bak, sonra gereken satırları oku.

## C. MCP köprüsü (P16, P17)

### 1. n8n tarafı: `05-kb-mcp`'yi hazırla

1. Önce `01-klasik-rag`'i çalıştır: `imbat_kb` deposu boşsa araç boş döner.
2. `05-kb-mcp.json`'u içe aktar.
3. `Embedding` node'unda kendi Gemini credential'ını seç. Model, `01`'deki embedding modeliyle aynı olmalı.
4. `Imbat KB MCP` node'unu aç. Authentication: Bearer Auth. Credential alanında yeni bir Bearer Auth credential oluştur, adını `imbat-kb-token` koy ve kendi uydurduğun uzun, rastgele bir token yaz. Bu token'ı bir yere not et; kimseyle paylaşma, ekranda gösterme.
5. `imbat_bilgi_bankasi` node'unun Workflow alanı aynı workflow'u gösterir. Hata verirse listeden `05 Imbat KB MCP (1.7)` workflow'unu seç.
6. Workflow'u kaydet ve yayına al (publish ya da active; etiket provada kontrol).
7. `Imbat KB MCP` node'unda Production URL'yi kopyala. Aşağıdaki komuttaki adres (`https://n8n.burakcanpolat.dev/mcp/imbat-kb`) eğitmenin instance'ıdır; sen ekrandaki Production URL'i esas al ve komutta onu kullan.

### 2. Claude Code tarafı: bağlantıyı ekle (P16)

Terminalde, kit klasöründeyken şu komutu çalıştır (P16). Adresin yerine kopyaladığın Production URL'i, `<TOKEN>` yerine `imbat-kb-token` credential'ına yazdığın token'ı koy; açılı parantezleri (`<` ve `>`) de sil:

```
claude mcp add --transport http imbat-kb https://n8n.burakcanpolat.dev/mcp/imbat-kb --header "Authorization: Bearer <TOKEN>"
```

Komut, Claude Code MCP belgelerindeki biçimdir. Windows terminallerinde tırnak davranışı provada kontrol; hata alırsan komutu tek satır olarak ve tırnakları değiştirmeden yeniden dene.

Bağlantıyı kontrol et:

```
claude mcp list
```

Listede `imbat-kb` görünmeli ve bağlantı durumu hatasız olmalı.

### 3. Soruyu sor (P17)

Claude Code'u yeniden aç (`claude`) ve şunu yaz (P17):

```
imbat-kb MCP sunucusundaki aracı kullanarak cevap ver, klasördeki dosyaları okuma: iptal edersem param ne zaman hesabima gecer
```

**Ne görmelisin:**

- Transcript'te `imbat_bilgi_bankasi` araç çağrısı; girdi olarak Claude'un yazdığı `soru`.
- Araçtan dönen 4 parça; her birinin başında `[kaynak: dosya_adı | bölüm]` etiketi.
- Cevap: iade 7 iş günü içinde karta yansır, kesinti yapılmaz; kaynak `03-iptal-ve-iade.md`.
- Soru Türkçe karaktersiz ve belgedeki kelimelerle örtüşmüyor ("param hesabıma geçer" ile "karta yansır"); anlam araması yine de doğru parçayı buldu. B'deki grep yolunun zorlanabileceği tür bu.
- n8n'de Executions altında `05-kb-mcp` çalıştırması: alt akışın girdisi (`soru`) ve çıktısı (`sonuc`).

## Çalışmazsa

- **`claude mcp list` bağlantı hatası:** URL'nin Production URL olduğundan (Test URL değil) ve workflow'un yayında olduğundan emin ol; token'ı kontrol et.
- **Araç boş dönüyor:** `imbat_kb` boştur; `01`'i yeniden çalıştır (n8n her yeniden başladığında depo silinir).
- **Model dosyaları okuyor:** P17'deki "klasördeki dosyaları okuma" kısmını değiştirmeden gönder; yine de okursa Claude Code'u kit klasörü dışında bir klasörde aç.
- **Token sızdıysa:** n8n'de `imbat-kb-token` credential'ının token'ını değiştir, P16'yı yeni token ile tekrar çalıştır (önce `claude mcp remove imbat-kb`).
