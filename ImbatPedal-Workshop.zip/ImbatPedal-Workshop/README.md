# İmbat Pedal Workshop Kiti

"2023'ten 2026'ya: Belgelerinden Cevap Veren Asistan" eğitiminin (27 Eylül 2026, 11:00-12:30 Türkiye saati) katılımcı kiti.

## Bu kit nedir

Bu kitle n8n'de, belgelerinden cevap veren bir asistanı önce 2023'ün klasik RAG yöntemiyle kurar, sonra aynı asistanı 2026'nın agentic yapısına taşırsın. Senaryo İmbat Pedal: İzmir'de dört şubeli, kurgusal bir bisiklet kiralama işletmesi. Altı belgenin hepsi kurgusaldır; içlerinde gerçek kişi, adres, telefon ya da marka yoktur. Kendi verini denerken de aynı kuralı koru: kişisel veri bu hatlara girmez.

## İçindekiler

```
ImbatPedal-Workshop/
  README.md                    bu dosya
  belgeler/                    6 kurgusal belge (Markdown)
    01-kiralama-kosullari.md
    02-fiyat-listesi.md
    03-iptal-ve-iade.md
    04-hasar-ve-guvence.md
    05-subeler-ve-saatler.md
    06-sss.md
  workflows/                   n8n'e içe aktarılacak 5 workflow
    01-klasik-rag.json
    02-agentic.json
    03-context.json
    04-ozetci-alt-workflow.json
    05-kb-mcp.json
  prompts.md                   P1-P19, eğitimde yazılan tüm metinler
  test-sorulari.md             10 test sorusu, beklenen cevap, kaynak belge
  test-sorulari.csv            aynı 10 soru, tablo biçiminde
  n8n-agents-kurulum.md        1.7: n8n Agents ve Knowledge
  claude-code-kurulum.md       1.7: Claude Code ile grep ve MCP köprüsü
  sozluk.md                    15 terim, Türkçe karşılık
```

Belgelerin metni `01-klasik-rag.json` içindeki "Belgeler" Code node'una da gömülüdür. n8n tarafında dosya yüklemen gerekmez; `belgeler/` klasörü 1.7'deki Claude Code ve n8n Agents yolları ile senin okuman için var.

## Kurulum

### 1. n8n

Üç yoldan birini seç:

- **n8n Cloud denemesi:** 14 gün, kart gerekmez, 1.000 execution. Denemede bir çalıştırma en fazla 180 saniye sürebilir; kitin yükleme adımı kısa tutuldu.
- **Docker ile kendi bilgisayarında (self-hosted).**
- **`npx n8n`:** güncel n8n paketi Node.js 24 ister. Bu yol denemek içindir, üretim için önerilmez.

### 2. Google AI Studio anahtarı: neden gerekli

Kitteki bütün workflow'lar tek bir anahtarla çalışır: Google AI Studio'dan alınan Gemini API anahtarı. Bu anahtar iki işi birden görür:

- **Google Gemini Chat Model:** asistanın düşünen ve cevap yazan modeli.
- **Embeddings Google Gemini:** belgeleri ve soruları anlam koordinatına (embedding) çeviren model. Klasik RAG'in de agentic aramanın da temeli budur.

Anahtarı aistudio.google.com adresinde oluştur. Ücretsiz katmanda gönderilen içerik Google tarafından ürün geliştirmede kullanılabilir; kitteki veri bu yüzden kurgusaldır. Anahtarını kimseyle paylaşma, ekranda gösterme.

### 3. Credential

n8n'de anahtar bir kez credential olarak kaydedilir, node'lar oradan kullanır. Herhangi bir Gemini node'unu aç, Credential alanında Create new credential, API Key alanına anahtarı yapıştır, Save. Credential türünün editördeki adı provada kontrol edilecek.

Kitteki JSON'larda credential adı yer tutucu olarak `Google Gemini (AI Studio)` yazar; içe aktardıktan sonra aşağıdaki her node'u açıp kendi credential'ını seç:

| Workflow | Kendi Gemini credential'ını seçeceğin node'lar | Başka credential |
| :-- | :-- | :-- |
| `01-klasik-rag` | `Embedding (yükleme)`, `Embedding (sorgu)`, `Gemini (zincir)` | yok |
| `02-agentic` | `Gemini`, `Embedding` | yok |
| `03-context` | `Gemini`, `Embedding` | yok |
| `04-ozetci-alt-workflow` | `Embedding`, `Gemini` | yok |
| `05-kb-mcp` | `Embedding` | Bearer Auth credential `imbat-kb-token` (`Imbat KB MCP` node'unda) |

Kural: yükleme ve sorgu tarafındaki embedding node'larında aynı model seçili olmalı. Model değişirse `01`'i yeniden çalıştır.

## Sıra: 01 her zaman önce

Workflow'ları numara sırasıyla içe aktar: yeni workflow, sağ üst menü, Import from File (etiket provada kontrol). Alternatif: dosyanın içeriğini kopyala, boş canvas'a Ctrl+V (Mac'te Cmd+V).

| Sıra | Dosya | Ünite | Ne işe yarar |
| :-- | :-- | :-- | :-- |
| 1 | `01-klasik-rag.json` | 1.3 | 6 belgeyi `imbat_kb` deposuna yükler; 2023 tarzı sabit soru-cevap zinciri |
| 2 | `02-agentic.json` | 1.5 | Aynı depo agent'ın aracı (`belge_arama`), yanında `web_arama`. 1.5'te yetişemeyen bunu içe aktarır |
| 3 | `03-context.json` | 1.6, 1.8 (1.1'deki gösterim) | Bitmiş asistan: System Message, iyi araç açıklaması, kaynak etiketi, Simple Memory |
| 4 | `04-ozetci-alt-workflow.json` | 1.6 bonus | 8 parça okur, 3 cümlelik kaynaklı özet döner |
| 5 | `05-kb-mcp.json` | 1.7 (eğitmen gösterir, sen evde) | Bilgi bankasını MCP ile Claude Code'a açar |

1.2'deki `Imbat Asistan` workflow'unu kit kullanmadan elle kurarsın (Chat Trigger, AI Agent, Google Gemini Chat Model); 1.5 ve 1.6'da ona araç ve ayar eklersin. `02` ve `03` aynı asistanın o ünitelerin sonundaki hâlidir.

## Simple Vector Store yeniden başlatmada boşalır

Simple Vector Store veriyi n8n'in belleğinde tutar. n8n yeniden başladığında depo silinir. Bu yüzden:

- Her n8n yeniden başlatmasından sonra önce `01-klasik-rag` içinde "Belgeleri yükle" ile workflow'u çalıştır. Sonra `02`, `03`, `04` ve `05` aynı `imbat_kb` deposunu okur.
- "Bir şey bulamadım" ya da boş araç sonucu görürsen ilk şüpheli boş depodur: `01`'i yeniden çalıştır.
- n8n Cloud'da Simple Vector Store en fazla 100 MB tutar ve veriyi 7 gün saklar; kendi kurulumunda (self-hosted) varsayılan olarak sınır ve süre yoktur, ama yeniden başlatmada yine silinir.
- `01`'de Clear Store açık: her çalıştırma depoyu temizleyip yeniden doldurur, kopya parça birikmez.
- Memory key'ler workflow'lar arasında ve instance genelinde paylaşılır: aynı n8n'i kullanan herkes `imbat_kb`'yi okuyabilir. Paylaşılan bir instance'ta herkes kendi key'ini kullanır ve depoya asla hassas veri girmez.

## Üniteleri handbook ile tekrar etmek

Eğitimi kaçırdıysan ya da yalnız izlediysen, handbook'taki ünite kartlarını sırayla aç; her kartta tıklama adımları ve hangi promptun yazılacağı var. Promptların metni `prompts.md` içinde, kimlikleriyle (P1-P19).

| Ünite | Kit dosyası | Ne yaparsın | Promptlar |
| :-- | :-- | :-- | :-- |
| 1.1 Açılış | `03-context` (izle) | Bitmiş asistanın kaynaklı cevabını gör | P1 |
| 1.2 n8n turu | yok, elle | `Imbat Asistan`: Chat Trigger, AI Agent, Google Gemini Chat Model; ilk cevap | P2 |
| 1.3 Klasik RAG | `01` | İçe aktar, credential seç, "Belgeleri yükle" çalıştır, Open chat | P2, P3, P4, P5 |
| 1.4 Ne değişti | yok | Handbook referansını oku | yok |
| 1.5 Agentic | `02` | `belge_arama` ve `web_arama` araçları; Executions'ta araç seçimi | P6, P7, P8, P2, P9 |
| 1.6 Context engineering | `03` | System Message, kötü ve iyi açıklama, "belgelerimizde yok", Simple Memory | P10, P11, P12, P6, P4, P2, P5 |
| 1.7 Yeni yapılar | `05`, `belgeler/` | `n8n-agents-kurulum.md` ve `claude-code-kurulum.md` | P13-P17 |
| 1.8 Ölçüm | `03`, `test-sorulari.md` | 10 soruyu sor, beklenenle karşılaştır, skorla | P3, P18, P19 |

## Bu akşam ne denenir

1. `test-sorulari.md` içindeki 10 soruyu `03-context`'e sor, her doğru cevaba 1 puan ver.
2. `belge_arama` node'unda Limit'i 4'ten 2'ye indir, aynı 10 soruyu yeniden sor, skorları karşılaştır.
3. Kişisel veri içermeyen 5 belgeni aynı hatta koy ve 5 soruluk kendi test setini yaz.
4. Bonus: `04` (özetçi alt workflow) ve `05` (MCP köprüsü). `05` için Claude Code'a bağlanma komutu (P16):

```
claude mcp add --transport http imbat-kb <PRODUCTION_URL> --header "Authorization: Bearer <TOKEN>"
```

Ayrıntı: `claude-code-kurulum.md`.

## Provada kontrol: karşılaşabileceğin farklar

Aşağıdakiler eğitim öncesi provada kontrol edilecek maddeler. Senin ekranında farklı görünürse şaşırma; parantez içindeki yolu izle.

- **Sohbet modeli kimliği:** JSON'larda katalog varsayılanı `models/gemini-3-flash-preview` yazılı. Listede yoksa ya da hata verirse Model listesindeki güncel ücretsiz Flash modelini seç.
- **Embedding modeli kimliği:** JSON'larda katalog varsayılanı `models/gemini-embedding-001` yazılı. Listende `gemini-embedding-2` varsa onu seçmek önerilir; hangisini seçersen seç, yükleme ve sorgu tarafında aynı model olmalı.
- **Node ve menü etiketleri:** "Import from File" menü adı; canvas'ta Chat Trigger, Manual Trigger, Execute Workflow Trigger ve Call n8n Sub-Workflow Tool başlıkları; "Retrieve Documents (As Tool for AI Agent)" seçeneği; Gemini credential türünün adı; n8n Agents sekmesinin adı.
- **Memory Key biçimi:** JSON'da `imbat_kb` elle yazılmış (Manual). Alan boş görünürse listeden `imbat_kb`'yi seç.
- **İçe aktarmada credential:** credential kendiliğinden bağlanmayabilir; yukarıdaki tablodaki node'larda elle seç.
- **`web_arama` (SearXNG):** yalnız eğitmenin sunucusunda çalışır. Sende yoksa node'u sil ya da yerine Wikipedia aracı ekle (anahtarsız çalışması provada kontrol).
- **`04` ve `05` Code node'ları:** vektör deposundan gelen parçanın alan adları provada kontrol; kod iki olası biçimi de okuyacak şekilde yazıldı.
- **`05` alt akış seçimi:** `imbat_bilgi_bankasi` node'unun Workflow alanı `{{ $workflow.id }}` ile aynı workflow'u gösterir. Hata verirse listeden `05 Imbat KB MCP (1.7)` workflow'unu seç.
- **`03` içindeki `ozetci`:** bilerek bağlantısız ve Workflow alanı boş gelir; bonus notundaki adımlarla `04`'e bağlanır.

## Sıfırlama ve güvenlik

- **Sıfırlama:** sohbet panelinde oturumu sıfırla; depo boşsa `01`'i yeniden çalıştır.
- **Dolaylı prompt injection:** getirilen bir belge ya da web sonucu, modele talimat gibi görünen metin taşıyabilir. Kaynağını bilmediğin metni bilgi bankasına koyma.
- **Kişisel veri:** vektör deposuna ve ücretsiz katmana kişisel veri girmez.
- **Anahtarlar:** Gemini anahtarı ve `05`'in Bearer token'ı kitte yok ve kite girmez; ekran paylaşırken gösterme.
