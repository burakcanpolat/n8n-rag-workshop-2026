# Test Soruları (10)

Asistanı tahminle değil ölçerek değerlendir. Her soruyu sohbeti sıfırlayarak sor, cevabı "Beklenen" ile karşılaştır: beklenen bilgi doğru ve kaynak etiketi doğru belgeyi gösteriyorsa 1 puan (T10'un ölçütü farklı, kendi bölümüne bak). Toplam skor 0-10.

Ünite 1.8'de canlı sorulan 3 soru "CANLI 1.8" ile işaretli (sıra: P3, P18, P19). Aynı sorular `test-sorulari.csv` dosyasında da var.

## T01

```
Rezervasyonumu başlangıçtan 12 saat önce iptal edersem ne kadar iade alırım?
```

- **Beklenen:** yüzde 50
- **Kaynak belge:** `03-iptal-ve-iade.md`
- **Tür:** doğrudan (P14)
- **Belgedeki dayanak:** Geç iptal: başlangıca 24 saatten az kala iptalde ödenen tutarın yüzde 50'si iade edilir.

## T02 · CANLI 1.8 (P3)

```
iptal edersem param ne zaman hesabima gecer
```

- **Beklenen:** 7 iş günü, kesinti yok
- **Kaynak belge:** `03-iptal-ve-iade.md`
- **Tür:** Türkçe karaktersiz (P3)
- **Belgedeki dayanak:** Kartla ödemede iade 7 iş günü içinde karta yansır; iadelerden kesinti yapılmaz.

## T03 · CANLI 1.8 (P18)

```
İadelerinizde kesinti yapıyor musunuz?
```

- **Beklenen:** hayır, kesinti yok
- **Kaynak belge:** `03-iptal-ve-iade.md`
- **Tür:** ek varyantı (P18)
- **Belgedeki dayanak:** İadelerden kesinti yapılmaz; tutar karta eksiksiz geri ödenir.

## T04

```
KB-204 günlüğü kaç TL?
```

- **Beklenen:** 750 TL
- **Kaynak belge:** `02-fiyat-listesi.md`
- **Tür:** ürün kodu
- **Belgedeki dayanak:** KB-204 elektrikli bisiklet günlük 750 TL.

## T05

```
AK-02 nedir, günlüğü kaç TL?
```

- **Beklenen:** çocuk koltuğu, 50 TL
- **Kaynak belge:** `02-fiyat-listesi.md`
- **Tür:** ürün kodu
- **Belgedeki dayanak:** AK-02 çocuk koltuğu, günlük 50 TL (06-sss.md de aynı bilgiyi verir).

## T06

```
Elektrikli bisiklet için yaş sınırı var mı?
```

- **Beklenen:** 18 yaş
- **Kaynak belge:** `01-kiralama-kosullari.md`
- **Tür:** doğrudan
- **Belgedeki dayanak:** Elektrikli bisiklet yalnızca 18 yaş ve üstüne kiralanır.

## T07

```
Alsancak'tan alıp Karşıyaka'ya bırakırsam ek ücret var mı?
```

- **Beklenen:** 75 TL
- **Kaynak belge:** `05-subeler-ve-saatler.md`
- **Tür:** doğrudan
- **Belgedeki dayanak:** Şubeler arası bırakma tek yön 75 TL.

## T08

```
Güvence almadım, lastik patladı, ne öderim?
```

- **Beklenen:** 150 TL
- **Kaynak belge:** `04-hasar-ve-guvence.md`
- **Tür:** yorum
- **Belgedeki dayanak:** Güvence yoksa lastik onarımı 150 TL.

## T09

```
karsiyaka pazar kacta kapaniyor
```

- **Beklenen:** 18:00
- **Kaynak belge:** `05-subeler-ve-saatler.md`
- **Tür:** Türkçe karaktersiz
- **Belgedeki dayanak:** Karşıyaka şubesi pazar günü 10:00-18:00 açık.

## T10 · CANLI 1.8 (P19)

```
Kış aylarında kayak ekipmanı kiralıyor musunuz?
```

- **Beklenen:** "Bu bilgi belgelerimizde yok." ya da belgelerin dışına çıkmayan net bir hayır. Fiyat listesinde yalnız dört bisiklet türü olduğu için model kaynaklı "Hayır, yalnızca bisiklet kiralıyoruz" diyebilir; bu da doğrudur.
- **Puan ölçütü:** uydurma iddia yok. Kalıp cümle şart değil; belgelerde olmayan bir şey (fiyat, tarih, ürün) söylerse 0 puan.
- **Kaynak belge:** yok (kayak hiçbir belgede yok)
- **Tür:** belgede yok (P19)
- **Belgedeki dayanak:** Kayak hiçbir belgede geçmez; asistan tahmin yürütmemeli.

## Skor tablosu

| Deneme | Ayar | Skor (0-10) | Not |
| :-- | :-- | :-- | :-- |
| 1 | `belge_arama` Limit 4 | | |
| 2 | `belge_arama` Limit 2 | | |
