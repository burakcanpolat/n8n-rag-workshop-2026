# n8n Agents ve Knowledge Kurulumu (Ünite 1.7, A kapısı)

Bu yol aynı altı belgeye embedding kullanmadan bakar. Agent, Knowledge'a koyduğun dosyaların adlarını tarar, ripgrep ile kelime arar ve gereken satırları okur. Eğitimde bu kısmı eğitmen gösterir (WATCH); sen evde aynı adımları kendi n8n'inde deneyebilirsin.

## Önce bil: neye bağlı

- **n8n Agents Preview durumunda.** Özellik tümüyle önizleme aşamasında; ekranlar ve etiketler değişebilir.
- **Nerede çalışır:** n8n Cloud'da güncel kararlı sürümde; self-hosted kurulumda 2.32.3 ve sonrası.
- **Knowledge Daytona ister (self-hosted).** Knowledge'daki dosya arama işlemleri bir Daytona sandbox içinde çalışır. Self-hosted n8n'inde Daytona yoksa Agents sekmesini görsen bile Knowledge araması çalışmaz. Bu dosyada "Daytona gerekir" işaretli her adım bu şarta bağlıdır.
- **Queue mode desteklenmez.** n8n'in queue mode'da çalışıyorsa Agents çalışmaz.
- **Her agent turu bir execution sayılır.** Cloud denemesindeki execution kotası buna göre azalır.
- **Self-hosted ayarları (provada kontrol):** modülün açılması için `N8N_ENABLED_MODULES` içine `agents` eklenmesi, sandbox için `N8N_AGENTS_AI_SANDBOX_ENABLED` ve Daytona anahtarı, ardından n8n'in yeniden başlatılması. Eğitmenin sunucusunda bu ayarlar provada denenir; senin kurulumunda farklı olabilir.

## 1. Agent'ı oluştur

1. n8n'in sol menüsünde Agents sekmesini aç (etiket provada kontrol).
2. Yeni bir agent oluştur, adını `Imbat Bilgi` koy.
3. Bir model ve onun credential'ını seç. Listede Gemini varsa 1.2'de oluşturduğun Google Gemini credential'ını bağla (Agents'ta hangi sağlayıcıların ve model adlarının listelendiği provada kontrol).

## 2. Instructions alanına P13'ü yapıştır

Agent'ın Instructions alanına aşağıdaki metni olduğu gibi yapıştır (P13):

```
Sen İmbat Pedal'ın müşteri asistanısın. Cevapları yalnızca Knowledge'daki belgelerden ver ve kullandığın dosyayı [kaynak: dosya_adı] biçiminde yaz. Belgelerde yoksa "Bu bilgi belgelerimizde yok." de. Türkçe, kısa cevap ver.
```

Bu metin, 1.6'daki System Message'ın (P10) kısa hâlidir: kaynak etiketi ve "belgelerimizde yok" kuralı aynı.

## 3. Knowledge'a 6 belgeyi yükle (Daytona gerekir)

1. Agent'ın Knowledge sekmesini aç.
2. Kitin `belgeler/` klasöründeki 6 Markdown dosyasını yükle:
   - `01-kiralama-kosullari.md`
   - `02-fiyat-listesi.md`
   - `03-iptal-ve-iade.md`
   - `04-hasar-ve-guvence.md`
   - `05-subeler-ve-saatler.md`
   - `06-sss.md`
3. Dosya adlarını değiştirme: agent cevapta bu adları kaynak olarak yazar.

Knowledge csv, pdf, markdown ve txt dosyası kabul eder. Burada embedding ya da vektör deposu yok; `01-klasik-rag`'i çalıştırmış olman gerekmez.

## 4. Akış: P13'ten P14'e

Eğitimdeki sıra iki adımdır: talimat (P13) kurulum sırasında bir kez yazılır, soru (P14) agent'ın sohbetinde sorulur.

1. P13 Instructions alanında, 6 belge Knowledge'da. Agent'ı kaydet.
2. Agent'ın sohbetini aç ve P14'ü gönder (test setindeki T01):

```
Rezervasyonumu başlangıçtan 12 saat önce iptal edersem ne kadar iade alırım?
```

## 5. Ne görmelisin (Daytona gerekir)

- **Araç çağrıları:** oturum kaydında agent'ın sırayla dosya adlarını taradığını, ripgrep ile "iptal" gibi bir kelime aradığını ve bulduğu dosyadan ilgili satırları okuduğunu görürsün.
- **Cevap:** yüzde 50 iade ve `[kaynak: 03-iptal-ve-iade.md]`.
- **Karşılaştır:** aynı soru 1.3'teki klasik zincirde anlam aramasıyla, burada kelime aramasıyla cevaplandı. Kelime araması kodları ve tam adları (KB-204 gibi) iyi bulur; soru ile belge ortak kelime paylaşmıyorsa kaçırabilir. Denemek için P3'ü de sor ve 1.7'deki MCP yoluyla (P17) karşılaştır.

## Çalışmazsa

- **Agents sekmesi yok:** sürümün 2.32.3'ten eskidir ya da modül kapalıdır (self-hosted ayarları provada kontrol).
- **Agent cevap veriyor ama dosya araması yok ya da hata veriyor:** Knowledge için Daytona yoktur ya da sandbox kapalıdır. Bu durumda aynı dersi `claude-code-kurulum.md` içindeki grep yolu (P15) ile görebilirsin; o yol Daytona istemez.
- **n8n queue mode'da:** Agents bu modda desteklenmez.
