# Promptlar (P1-P19)

Eğitimde yazılan her metin burada, kimliğiyle ve birebir; kod bloğunun içini olduğu gibi kopyala. Başlıkta ünite ve metnin nereye yazılacağı yazar.

## P1 · 1.1 · n8n chat (`03-context`)

Amaç: Bitmiş asistan gösterimi.

```
Elektrikli bisikleti Alsancak şubesinden alıp Karşıyaka şubesine bırakırsam, bir günlük kiralama toplam kaç TL tutar?
```

## P2 · 1.2, 1.3, 1.5, 1.6 · n8n chat

Amaç: Aynı soru, dört dönem.

```
İmbat Pedal'da elektrikli bisikletin günlük kiralama ücreti ne kadar?
```

## P3 · 1.3, 1.8 · n8n chat

Amaç: Türkçe karaktersiz soru (T02).

```
iptal edersem param ne zaman hesabima gecer
```

## P4 · 1.3, 1.6 · n8n chat

Amaç: Belgede olmayan soru.

```
Tekne de kiralıyor musunuz?
```

## P5 · 1.3 yedek, 1.6 · n8n chat

Amaç: Hafıza gerektiren takip sorusu.

```
Peki haftalığı kaç TL?
```

## P6 · 1.5, 1.6 · node alanı: `belge_arama` Description

Amaç: İyi araç açıklaması.

```
İmbat Pedal belgelerinde anlamca arama yapar: kiralama koşulları, fiyat listesi ve ürün kodları, iptal ve iade, hasar ve güvence, şubeler ve çalışma saatleri, sık sorulan sorular. İmbat Pedal ile ilgili her soruda önce bunu kullan.
```

## P7 · 1.5 · node alanı: `web_arama` Description

Amaç: Web aracı açıklaması.

```
İnternette güncel ve genel bilgi arar: hava durumu, haberler, genel sorular. İmbat Pedal'ın fiyatları, kuralları ve şubeleri için kullanma; onlar için belge_arama aracını kullan.
```

## P8 · 1.5 · node alanı: `web_arama` Query Parameter `q`

Amaç: Model arama sorgusunu yazar.

```
{{ $fromAI('q', 'Aranacak kısa arama sorgusu', 'string') }}
```

## P9 · 1.5 · n8n chat

Amaç: İki aracı birlikte gerektiren soru.

```
Bu hafta sonu İzmir'de hava nasıl olacak? Yağmur yağarsa rezervasyonumu ücretsiz iptal edebilir miyim?
```

## P10 · 1.6 · node alanı: AI Agent System Message

Amaç: Masaya kalıcı yazılanlar.

```
Sen İmbat Pedal'ın müşteri asistanısın. İmbat Pedal, İzmir'de dört şubesi olan kurgusal bir bisiklet kiralama işletmesidir.
- İmbat Pedal ile ilgili her soruda önce belge_arama aracını kullan. web_arama aracını yalnızca hava durumu gibi güncel ve genel bilgiler için kullan.
- İmbat Pedal hakkındaki cevapları yalnızca belgelerde bulduğun metne dayandır. Belgelerde yoksa tam olarak "Bu bilgi belgelerimizde yok." yaz, tahmin yürütme.
- Cevabın sonuna kullandığın her belgeyi [kaynak: dosya_adı] biçiminde yaz. Bilgi internetten geldiyse [kaynak: web] yaz.
- Her zaman Türkçe, kısa ve net cevap ver.
```

## P11 · 1.6 · node alanı: `belge_arama` Description

Amaç: Kötü açıklama.

```
veri
```

## P12 · 1.6 · n8n chat

Amaç: Açıklama testi.

```
Karşıyaka şubesi pazar günü kaçta kapanıyor?
```

## P13 · 1.7 · n8n Agents, Instructions

Amaç: Agents talimatı.

```
Sen İmbat Pedal'ın müşteri asistanısın. Cevapları yalnızca Knowledge'daki belgelerden ver ve kullandığın dosyayı [kaynak: dosya_adı] biçiminde yaz. Belgelerde yoksa "Bu bilgi belgelerimizde yok." de. Türkçe, kısa cevap ver.
```

## P14 · 1.7 · n8n Agents chat

Amaç: Ortak soru (T01).

```
Rezervasyonumu başlangıçtan 12 saat önce iptal edersem ne kadar iade alırım?
```

## P15 · 1.7 · Claude Code

Amaç: Grep ile aynı soru.

```
belgeler klasöründeki dosyalara bakarak cevap ver ve hangi dosyadan bulduğunu yaz: Rezervasyonumu başlangıçtan 12 saat önce iptal edersem ne kadar iade alırım?
```

## P16 · 1.7 · terminal

Amaç: MCP bağlantısı.

```
claude mcp add --transport http imbat-kb <PRODUCTION_URL> --header "Authorization: Bearer <TOKEN>"
```

## P17 · 1.7 · Claude Code

Amaç: MCP ile anlam araması.

```
imbat-kb MCP sunucusundaki aracı kullanarak cevap ver, klasördeki dosyaları okuma: iptal edersem param ne zaman hesabima gecer
```

## P18 · 1.8 · n8n chat

Amaç: Ek varyantı (T03).

```
İadelerinizde kesinti yapıyor musunuz?
```

## P19 · 1.8 · n8n chat

Amaç: Belgede yok (T10).

```
Kış aylarında kayak ekipmanı kiralıyor musunuz?
```
