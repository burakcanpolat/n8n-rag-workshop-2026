# Fiyat Listesi ve Ürün Kodları

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Bisikletler

İmbat Pedal'daki her bisiklet türünün bir ürün kodu vardır. Ürün kodları KB ile başlar. Aşağıdaki tabloda saatlik, günlük ve haftalık kiralama ücretleri yer alır.

| Ürün kodu | Bisiklet | Saatlik | Günlük | Haftalık |
| :-- | :-- | :-- | :-- | :-- |
| KB-101 | Şehir bisikleti | 90 TL | 350 TL | 1.750 TL |
| KB-204 | Elektrikli bisiklet | 180 TL | 750 TL | 3.900 TL |
| KB-305 | Çocuk bisikleti | 60 TL | 220 TL | 1.100 TL |
| KB-410 | Tandem | 200 TL | 800 TL | Haftalık kiralama yok |

KB-101 şehir bisikleti, şehir içinde kısa ve orta mesafeli sürüşler için vitesli ve sepet takılabilen bir bisiklettir. KB-204 elektrikli bisiklet, pedal desteği olan ve yokuşlarda kolaylık sağlayan bir bisiklettir; yalnızca 18 yaş ve üstüne kiralanır ve kiralamada 2.000 TL kart provizyonu alınır. KB-305 çocuk bisikleti, küçük boylu çocuklar için tasarlanmıştır. KB-410 tandem, iki kişinin birlikte pedal çevirdiği bir bisiklettir.

Tandem bisiklet yalnızca saatlik veya günlük kiralanabilir. KB-410 için haftalık kiralama yapılmaz.

Saatlik kiralama en az 1 saattir. Günlük kiralama 24 saat, haftalık kiralama 7 gün sürer. Süre dolduktan sonra yapılan teslimde, her başlayan saat için o bisikletin saatlik ücreti gecikme ücreti olarak alınır.

## Aksesuarlar

Aksesuarların ürün kodları AK ile başlar. Aksesuar ücretleri bisiklet ücretine eklenir.

- AK-01 Kask: ücretsizdir. Her kiralamada isteyen herkese kask verilir. İmbat Pedal kask kullanmayı önerir.
- AK-02 Çocuk koltuğu: günlük 50 TL. Şehir bisikletine takılır. Çocuk koltuğunun ağırlık sınırı Sık Sorulan Sorular belgesindedir.
- AK-03 Sepet ve kilit seti: günlük 40 TL. Sette bir ön sepet ve bir zincir kilit bulunur.

Aksesuarlar bisikletle birlikte teslim alınır ve bisikletle birlikte geri verilir. Kayıp veya hasarlı aksesuar için ücret, servis değerlendirmesinden sonra belirlenir.

## Genel

Bu listedeki bütün fiyatlara KDV dahildir. Fiyatlar tüm şubelerde aynıdır.

Pedal Güvence ücreti bu listede yer almaz. Güvence ücreti ve kapsamı Hasar ve Güvence belgesinde anlatılır.

Bisikleti aldığı şubeden farklı bir şubeye bırakmak isteyen müşteri için şubeler arası bırakma ücreti uygulanır. Bu ücret Şubeler ve Çalışma Saatleri belgesinde yer alır ve kiralama ücretine ayrıca eklenir.

10 ve üzeri bisikletlik grup kiralamalarında indirim uygulanır. Grup indiriminin oranı Sık Sorulan Sorular belgesindedir.

Ödeme yalnızca kartla alınır. Ücretler rezervasyon sırasında, rezervasyonsuz kiralamalarda ise bisiklet teslim alınırken tahsil edilir. İptal ve iade kuralları İptal ve İade belgesinde anlatılır.

Fiyat örneği: bir elektrikli bisikleti (KB-204) bir günlüğüne kiralayan ve yanına sepet ve kilit seti (AK-03) alan müşteri 750 TL ve 40 TL, toplam 790 TL öder. Aynı müşteri bisikleti farklı bir şubeye bırakırsa şubeler arası bırakma ücreti bu tutara eklenir.
