# Hasar ve Güvence

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Pedal Güvence

Pedal Güvence, kiralama sırasında oluşabilecek hasarlara karşı İmbat Pedal'ın sunduğu isteğe bağlı güvencedir. Pedal Güvence ücreti günlük 40 TL'dir.

Pedal Güvence kiralama sırasında alınır: rezervasyon yapılırken ya da en geç bisiklet teslim alınırken. Kiralama başladıktan sonra güvence eklenemez. Saatlik kiralamalarda da güvence ücreti günlük 40 TL olarak uygulanır; haftalık kiralamada güvence ücreti her gün için ayrı hesaplanır.

Güvence yalnızca kiralanan bisikleti ve birlikte alınan aksesuarları kapsar. Güvence ücreti, iptal durumunda İptal ve İade belgesindeki kurallara göre iade edilir. Kiralayan kişinin kendisine veya başkalarına ait eşyalar güvence kapsamında değildir.

## Küçük hasar

Küçük hasar; lastik, zincir ve fren ayarı ile ilgili sorunlardır. Patlayan lastik, atan veya kopan zincir ve ayarı bozulan fren küçük hasar sayılır.

Pedal Güvence alan müşteri için küçük hasarlar ücretsizdir. Müşteri sorunu şubeye bildirir, şube onarımı yapar ve müşteriden ücret alınmaz.

Küçük hasar yolda olursa müşteri bisikleti en yakın şubeye getirebilir. Şube listesi Şubeler ve Çalışma Saatleri belgesindedir.

## Büyük hasar

Büyük hasar; kadro, jant, elektrikli bisikletin motoru veya bataryası gibi parçalarda oluşan hasarlardır. Kaza sonucu kullanılamaz hale gelen bisiklet de büyük hasar sayılır.

Pedal Güvence alan müşterinin büyük hasardaki sorumluluk üst sınırı 1.000 TL'dir. Onarım bedeli 1.000 TL'yi aşsa bile güvenceli müşteri en fazla 1.000 TL öder. Onarım bedeli 1.000 TL'nin altındaysa müşteri yalnızca onarım bedelini öder.

Büyük hasarın bedeli servis değerlendirmesiyle belirlenir. Elektrikli bisiklette alınan 2.000 TL provizyon, hasar bedeli belirlendikten sonra çözülür.

## Güvence yoksa

Pedal Güvence almayan müşteri, kiralama sırasında oluşan hasarın bedelini öder. Sık görülen hasarların ücretleri şöyledir:

- Lastik onarımı: 150 TL. Lastik patlaması bu kapsamdadır.
- Zincir değişimi: 200 TL.
- Diğer hasarlar: servis değerlendirmesiyle belirlenir.

Örneğin güvence almayan ve kiralama sırasında lastiği patlayan müşteri, lastik onarımı için 150 TL öder. Güvencesiz müşteri için büyük hasarda bir üst sınır yoktur; bedel servis değerlendirmesine göre belirlenir.

Hasar ücretleri bisiklet geri teslim edilirken karttan tahsil edilir. Geri teslim sırasında görevli bisikleti müşteriyle birlikte kontrol eder ve fark edilen hasarı müşteriye gösterir.

## Hırsızlık

Kiralanan bisikletin çalınması durumunda Pedal Güvence iki şartla devreye girer. Birincisi, bisiklet çalındığında kilitli bırakılmış olmalıdır. İkincisi, olay için resmi bir tutanak tutulmuş olmalıdır.

Bu iki şart sağlanırsa hırsızlık güvence kapsamındadır ve büyük hasardaki gibi sorumluluk üst sınırı uygulanır. Bisiklet kilitsiz bırakılmışsa veya resmi tutanak yoksa hırsızlık güvence kapsamında değildir ve bisikletin bedeli servis değerlendirmesiyle belirlenir.

Kilit için AK-03 sepet ve kilit seti kiralanabilir. Aksesuar ücretleri Fiyat Listesi ve Ürün Kodları belgesindedir.

Hasar veya hırsızlık durumunda müşteri, kiralamayı yaptığı şubeye mümkün olan en kısa sürede bilgi verir.
