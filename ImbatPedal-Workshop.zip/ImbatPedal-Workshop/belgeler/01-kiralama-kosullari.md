# Kiralama Koşulları

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Kimler kiralayabilir

İmbat Pedal'da 18 yaş ve üstündeki herkes kendi adına bisiklet kiralayabilir. Kiralamayı yapan kişi, bisikleti teslim aldığı andan geri bıraktığı ana kadar bisikletten ve aldığı aksesuarlardan sorumludur.

12 ile 17 yaş arasındaki gençler yalnızca veli eşliğinde kiralama yapabilir. Bu durumda kiralama velinin adına açılır ve veli teslim sırasında şubede bulunur. Veli eşliğindeki gençler yalnızca şehir bisikleti ve çocuk bisikleti kiralayabilir.

Elektrikli bisiklet yalnızca 18 yaş ve üstündeki kişilere kiralanır. Bu kural veli eşliğinde de değişmez: 18 yaşından küçük biri elektrikli bisiklet kullanamaz. 12 yaşından küçük çocuklar için kiralamayı veli kendi adına yapar; bu çocuklar için çocuk bisikleti veya çocuk koltuğu seçilebilir. Çocuk koltuğu ile ilgili bilgiler Sık Sorulan Sorular belgesindedir.

## Gerekenler

Kiralama sırasında kimlik gösterilir. Kimlik yalnızca yaş kontrolü için görülür; kimlik bilgisi kaydedilmez, fotokopisi alınmaz ve sistemde saklanmaz.

Ödeme yalnızca kartla alınır. Nakit ödeme kabul edilmez. Önceden rezervasyon yapıldıysa kiralama ücreti, seçilen aksesuarlar ve varsa Pedal Güvence ücreti rezervasyon sırasında karttan tahsil edilir; rezervasyonsuz kiralamalarda bu tutarlar bisiklet teslim alınırken tahsil edilir. Fiyatların tamamı Fiyat Listesi ve Ürün Kodları belgesindedir.

Teslim sırasında görevli, bisikletin lastiklerini, frenlerini ve zincirini müşteriyle birlikte kontrol eder. Müşteri bisikleti bu kontrolden sonra teslim alır.

## Provizyon

Elektrikli bisiklet kiralamalarında karttan 2.000 TL provizyon alınır. Provizyon bir ödeme değildir; tutar kartta bloke edilir ve bisiklet teslim edildiğinde çözülür.

Bisiklet hasarsız ve zamanında teslim edilirse provizyon tutarının tamamı serbest kalır. Hasar veya gecikme varsa ilgili ücret ayrıca hesaplanır. Hasar kuralları Hasar ve Güvence belgesinde anlatılır. Şehir bisikleti, çocuk bisikleti ve tandem kiralamalarında provizyon alınmaz.

## Süreler

İmbat Pedal üç kiralama süresi sunar:

- Saatlik kiralama: en az 1 saattir. 1 saatten kısa kiralama yapılmaz.
- Günlük kiralama: 24 saattir. Bisiklet teslim alındığı saatten 24 saat sonra geri bırakılır.
- Haftalık kiralama: 7 gündür. Bisiklet teslim alındığı günün aynı saatinde, 7 gün sonra geri bırakılır.

Tandem bisiklet için haftalık kiralama yoktur; tandem yalnızca saatlik veya günlük kiralanabilir.

Kiralama süresi bisikletin teslim alındığı saatte başlar. Süre dolmadan erken teslim edilen bisiklet için kalan süre iade edilmez; bu kural İptal ve İade belgesinde de yer alır.

## Gecikme

Bisiklet kiralama süresi dolduktan sonra teslim edilirse gecikme ücreti uygulanır. Gecikmede her başlayan saat için o bisikletin saatlik ücreti alınır.

Örneğin günlük kiralanan bir şehir bisikleti süre dolduktan 1 saat 10 dakika sonra teslim edilirse iki başlayan saat için iki kez saatlik ücret ödenir. Gecikme ücreti bisiklet geri teslim edilirken karttan tahsil edilir.

Gecikme ihtimali olan müşteriler şubeyi önceden bilgilendirebilir, ancak bu bilgilendirme gecikme ücretini kaldırmaz. Kiralamayı uzatmak isteyen müşteri, süre dolmadan şubeye uğrayarak yeni bir kiralama açabilir.
