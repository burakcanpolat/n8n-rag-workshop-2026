# Şubeler ve Çalışma Saatleri

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Şubeler

İmbat Pedal'ın İzmir'de dört şubesi vardır:

- Alsancak şubesi
- Karşıyaka şubesi
- Bostanlı şubesi
- Göztepe şubesi

Şubeler yalnızca semt adıyla anılır. Dört şubede de aynı bisiklet türleri, aynı aksesuarlar ve aynı fiyatlar geçerlidir. Fiyatlar Fiyat Listesi ve Ürün Kodları belgesindedir.

Her şubede kiralama, teslim, iade ve küçük hasar onarımı yapılır. Rezervasyon hangi şubede yapıldıysa bisiklet o şubeden teslim alınır. Rezervasyonsuz gelen müşteriye, şubede uygun bisiklet varsa hemen kiralama yapılır. Her şubenin bisiklet sayısı sınırlı olduğu için hafta sonları rezervasyon önerilir.

## Hafta içi ve cumartesi

Pazartesiden cumaya kadar hafta içi günlerde ve cumartesi günü tüm şubeler 08:00-20:00 saatleri arasında açıktır.

Bu saatler dört şube için de aynıdır. Bisiklet teslim almak ve geri bırakmak yalnızca şubenin açık olduğu saatlerde mümkündür. Kapanış saatinden sonra bisiklet geri bırakılamaz. Bu nedenle kiralama süresinin, şubenin açık olduğu bir saatte dolacak şekilde planlanması önerilir. Şubeler öğle arası vermez; açılıştan kapanışa kadar kesintisiz hizmet verir.

## Pazar

Pazar günü şubeler 09:00-19:00 saatleri arasında açıktır.

Karşıyaka şubesi pazar günü farklı saatlerde çalışır: Karşıyaka şubesi pazar günü 10:00'da açılır ve 18:00'de kapanır. Diğer üç şube, yani Alsancak, Bostanlı ve Göztepe şubeleri, pazar günü 09:00-19:00 saatleri arasında açıktır.

Pazar günü Karşıyaka şubesine bisiklet bırakmayı planlayan müşterilerin 18:00'den önce şubede olması gerekir. Pazar sabahı Karşıyaka şubesinden bisiklet almak isteyen müşteri de 10:00'dan önce teslim alamaz; daha erken başlamak isteyen müşteri diğer üç şubeden birini seçebilir.

## Şubeler arası bırakma

Müşteri bisikleti aldığı şubeden farklı bir şubeye bırakabilir. Buna şubeler arası bırakma denir.

Şubeler arası bırakma tek yön için 75 TL'dir. Bu ücret kiralama ücretine ayrıca eklenir ve kiralama ücretiyle birlikte karttan tahsil edilir. Ücret, bisiklet türünden bağımsızdır; şehir bisikleti, elektrikli bisiklet, çocuk bisikleti ve tandem için aynıdır.

Örneğin elektrikli bisikleti (KB-204) Alsancak şubesinden alıp Karşıyaka şubesine bırakan müşteri, bir günlük kiralama için 750 TL kiralama ücreti ve 75 TL şubeler arası bırakma ücreti, toplam 825 TL öder.

Farklı şubeye bırakmak isteyen müşteri bunu kiralama sırasında belirtir. Bırakılacak şube, bırakma saatinde açık olmalıdır. Bisikleti aldığı şubeye geri bırakan müşteriden bırakma ücreti alınmaz.

## Resmi tatiller

Resmi tatil günlerinde pazar saatleri uygulanır. Resmi tatillerde şubeler 09:00-19:00 saatleri arasında açıktır; Karşıyaka şubesi resmi tatillerde de 10:00-18:00 saatleri arasında açıktır.

Resmi tatile denk gelen rezervasyonlar için iptal ve iade kuralları değişmez. İptal ve iade kuralları İptal ve İade belgesinde anlatılır.

Arife günleri ve özel günlerle ilgili saat değişiklikleri şubelerde önceden duyurulur. Duyuru olmayan günlerde bu belgedeki saatler geçerlidir. Resmi tatillerde de şubeler arası bırakma yapılabilir ve ücreti aynıdır.
