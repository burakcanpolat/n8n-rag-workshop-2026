# Sık Sorulan Sorular

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Kask ücretli mi?

Hayır, kask ücretsizdir. Kaskın ürün kodu AK-01'dir. Her kiralamada isteyen herkese ücretsiz kask verilir.

İmbat Pedal, özellikle elektrikli bisiklet ve tandem kullanan müşterilere kask kullanmayı önerir. Kasklar her kullanımdan sonra temizlenir. Farklı boylarda kask bulunur; müşteri bisikleti teslim alırken kendi boyuna uygun kaskı seçer.

Kask da diğer aksesuarlar gibi bisikletle birlikte geri verilir. Müşteri kendi kaskını getirmek isterse bunu da kullanabilir; kendi kaskını getiren müşteriye ek bir indirim uygulanmaz.

## Çocuk koltuğu var mı?

Evet. Çocuk koltuğunun ürün kodu AK-02'dir ve ücreti günlük 50 TL'dir. Diğer aksesuarların ücretleri Fiyat Listesi ve Ürün Kodları belgesindedir.

Çocuk koltuğu 22 kg'a kadar olan çocuklar için uygundur. 22 kg'ın üzerindeki çocuklar için çocuk koltuğu kullanılmaz; bu çocuklar için çocuk bisikleti (KB-305) önerilir.

Çocuk koltuğu şehir bisikletine takılır. Koltuğu şube görevlisi takar ve teslim sırasında müşteriyle birlikte kontrol eder. Çocuk koltuğu kullanılırken çocuğa da kask takılmalıdır.

## Yağmur yağarsa ne olur?

Yağmurlu havada da bisiklet teslim edilir. Müşteri isterse yağmurda da kiralamasını normal şekilde kullanabilir.

Yağmur tek başına ücretsiz iptal sebebi değildir. Hava koşullarına bağlı ücretsiz iptal yalnızca resmi turuncu ya da kırmızı hava uyarısı olan günler için geçerlidir. Ücretsiz iptal kuralının ayrıntıları İptal ve İade belgesindedir.

Yağmurlu günlerde frenler daha geç tutabilir. Müşterinin yavaş sürmesi ve ıslak zeminde dikkatli olması önerilir. Yağmur sırasında bisikletin şubeye erken getirilmesi mümkündür, ancak erken teslimde kalan süre iade edilmez.

## Bisikleti eve götürebilir miyim?

Günlük ve haftalık kiralamalarda evet. Günlük veya haftalık kiralanan bisiklet gece müşteride kalabilir ve müşteri bisikleti evine götürebilir.

Saatlik kiralamada bisiklet kiralama süresi bitince şubeye geri bırakılır; saatlik kiralanan bisikletin eve götürülmesi önerilmez. Şubeler gece kapalı olduğu için saatlik kiralanan bisiklet gece müşteride kalamaz.

Bisiklet evde veya dışarıda bırakılırken kilitli bırakılmalıdır. Kilitsiz bırakılan bisikletin çalınması güvence kapsamında değildir; bu konu Hasar ve Güvence belgesinde anlatılır.

## Grup kiralama yapıyor musunuz?

Evet. 10 ve üzeri bisikletlik grup kiralamalarında kiralama ücretine yüzde 10 indirim uygulanır.

Örneğin 10 şehir bisikletini (KB-101) bir günlüğüne kiralayan bir grup, toplam kiralama ücreti üzerinden yüzde 10 indirim alır. Grup indirimi bisiklet kiralama ücretine uygulanır; aksesuar ücretlerine, Pedal Güvence ücretine ve şubeler arası bırakma ücretine uygulanmaz. Grup kiralaması tek bir şubeden yapılır.

Grup kiralamalarında da her bisiklet için iptal ve iade kuralları aynıdır. 10 ve üzeri bisiklet için şubeye önceden rezervasyon yapılması önerilir, çünkü her şubedeki bisiklet sayısı sınırlıdır.

Okul, şirket veya dernek grupları da aynı indirimden yararlanır. Grup kiralamasında ödeme yine kartla alınır ve tek bir kart üzerinden yapılabilir. 10'dan az bisikletlik kiralamalarda grup indirimi uygulanmaz.
