# İptal ve İade

Bu belge kurgusaldır. İmbat Pedal gerçek bir işletme değildir.

## Ücretsiz iptal

İmbat Pedal'da önceden yapılan rezervasyonlar, kiralamanın başlangıç saatinden 24 saat öncesine kadar ücretsiz iptal edilebilir. Bu durumda ödenen tutarın tamamı iade edilir.

Örneğin cumartesi saat 10:00'da başlayacak bir rezervasyon, cuma saat 10:00'a kadar ücretsiz iptal edilebilir. İptal, rezervasyonun yapıldığı şubeye bildirilerek yapılır. İptalin hangi saatte yapıldığı, şubenin iptal kaydındaki saate göre belirlenir.

Ücretsiz iptal süresi saatlik, günlük ve haftalık kiralamaların hepsi için aynıdır. Rezervasyon başlangıca 24 saatten az kala yapıldıysa ücretsiz iptal süresi geçmiş sayılır ve geç iptal kuralı uygulanır.

## Geç iptal

Başlangıç saatine 24 saatten az kala yapılan iptallerde ödenen tutarın yüzde 50'si iade edilir. Kalan yüzde 50 iade edilmez.

Örneğin rezervasyonunu başlangıçtan 12 saat önce iptal eden müşteri, ödediği tutarın yüzde 50'sini geri alır. Başlangıçtan 1 saat önce yapılan iptal de geç iptal sayılır ve yine yüzde 50 iade yapılır.

Geç iptal kuralı bisiklet ücretine, aksesuar ücretlerine ve Pedal Güvence ücretine birlikte uygulanır. Şubeler arası bırakma ücreti de bu kurala dahildir.

## Başladıktan sonra

Kiralama başladıktan sonra iptal yapılamaz ve iade yoktur. Kiralama, bisikletin teslim alındığı saatte başlamış sayılır.

Bisiklet süre dolmadan erken teslim edilirse kalan süre iade edilmez. Örneğin haftalık kiralanan bir bisiklet 3 gün sonra geri getirilirse kullanılmayan 4 gün için ücret iadesi yapılmaz.

Rezervasyon saatinde şubeye gelmeyen ve iptal bildirmeyen müşteri için de iade yapılmaz.

## Hava durumu

Hava koşulları nedeniyle yapılan iptallerde özel bir kural vardır. Kiralama gününde o bölge için resmi turuncu ya da kırmızı hava uyarısı varsa, rezervasyon süreye bakılmaksızın ücretsiz iptal edilir ve ödenen tutarın tamamı iade edilir.

Yağmur tek başına ücretsiz iptal sebebi değildir. Resmi turuncu ya da kırmızı hava uyarısı olmayan yağmurlu bir günde normal iptal kuralları geçerlidir: başlangıçtan 24 saat öncesine kadar iptal ücretsizdir, 24 saatten az kala yapılan iptalde yüzde 50 iade edilir.

Yağmurlu havada bisiklet teslim alınmak istenirse bisiklet normal şekilde teslim edilir. Yağmurlu günlerle ilgili diğer bilgiler Sık Sorulan Sorular belgesindedir.

## İade yöntemi

İmbat Pedal'da ödemeler yalnızca kartla alındığı için iadeler de karta yapılır. Kartla yapılan ödemelerde iade, iptalden sonra 7 iş günü içinde karta yansır. İadenin hesaba geçme süresi kartı veren bankaya göre bu süre içinde değişebilir.

İadelerden kesinti yapılmaz. İşlem ücreti, hizmet bedeli veya benzeri bir kesinti uygulanmaz; iade edilecek tutar karta eksiksiz olarak geri ödenir.

Elektrikli bisiklet kiralamalarında alınan 2.000 TL provizyon bir ödeme olmadığı için iade kapsamında değildir; provizyon, bisiklet teslim edildiğinde çözülür.

İade durumu hakkında bilgi almak isteyen müşteri, rezervasyonu yaptığı şubeye danışabilir.
