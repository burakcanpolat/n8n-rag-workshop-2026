# Sözlük

Eğitimde geçen 15 terim; İngilizce terim, Türkçe karşılık ve tek cümlelik açıklama.

| Terim | Türkçe karşılık | Açıklama |
| :-- | :-- | :-- |
| chunk | parça | Belgenin, aranabilsin diye bölündüğü küçük metin parçası; kitte en fazla 800 karakter. |
| chunk overlap | parça örtüşmesi | Ardışık iki parçanın ortak paylaştığı metin; kitte 150 karakter, cümle ortadan bölünse de anlam kopmasın diye. |
| embedding | anlam vektörü | Bir metni anlamına göre bir sayı dizisine (anlam haritasında bir koordinata) çeviren gösterim; benzer anlamlı metinler birbirine yakın düşer. |
| vector store | vektör deposu | Parçaları embedding'leriyle birlikte saklayan ve soruya en yakın parçaları bulan depo; kitte Simple Vector Store, anahtarı `imbat_kb`. |
| retrieval | getirme | Soruya en uygun parçaları depodan bulup modelin önüne koyma adımı. |
| rerank | yeniden sıralama | Getirilen parçaları ikinci, daha dikkatli bir modelle yeniden sıralayıp en iyilerini öne alma. |
| context window | bağlam penceresi | Modelin tek seferde görebildiği metnin tamamı; eğitimdeki "masa". |
| system message | sistem mesajı | Her turda masaya konan kalıcı talimat; asistanın rolünü ve kurallarını söyler. |
| tool | araç | Agent'ın gerektiğinde çağırabildiği yetenek; kitte `belge_arama` ve `web_arama`. |
| tool description | araç açıklaması | Modelin aracı tanıdığı tek metin; aracı ne zaman seçeceğine buna bakarak karar verir. |
| memory | hafıza | Önceki sohbet turlarının masaya geri konması; kitte Simple Memory, son 5 tur. |
| sub-workflow | alt workflow | Başka bir workflow'un araç ya da adım olarak çağırdığı ayrı workflow; kitte `04` ve `05`'in alt akışı. |
| execution | çalıştırma kaydı | n8n'de her çalıştırmanın adım adım kaydı; hangi aracın çağrıldığı ve ne döndüğü burada görünür. |
| evaluation set | test seti | Beklenen cevabı ve kaynağı bilinen soru listesi; kitte 10 soru, `test-sorulari.md`. |
| indirect prompt injection | dolaylı prompt enjeksiyonu | Getirilen bir belgenin ya da web sonucunun içine gizlenmiş, modeli yönlendirmeye çalışan talimat. |
